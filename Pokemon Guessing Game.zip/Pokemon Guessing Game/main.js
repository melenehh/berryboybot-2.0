const printPk = document.getElementById("pokePrint");
let results = document.getElementById("results");
let genInput = "three";
const generations = {
    one: 151,
    two: 251,
    three: 386,
    four: 493,
    five: 649,
    six: 721,
    seven: 809,
    eight: 905,
    nine: 1025,
};

let chosenGen = generations[genInput];

let pokeNum = Math.floor(Math.random()*chosenGen) + 1;

let pokemon = {
    id: 0,
    name: "",
    types: [],
    color: "",
    desc: "",
    shape: ""
};

let hints = []
let hintIndex = 0

let numGuesses = 0
let currentGuess = ""

function capitalize(string){
    let firstLetter = string[0];
    return firstLetter.toUpperCase() + string.slice(1).toLowerCase();
}

async function fetchAnswer(){
    chosenGen = generations[genInput]
    pokeNum = Math.floor(Math.random()*chosenGen) + 1;
    try{
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokeNum}`);
        
        if(!response.ok){
            throw new Error("Could not fetch resource");
        }
        data = await response.json();
        pokemon.id = data.id;
        pokemon.name = data.name;
        if(data.types.length === 1){
            pokemon.types[0] = data.types[0].type.name;
            pokemon.types[1] = "mono type";
        } else {
            pokemon.types[0] = data.types[0].type.name;
            pokemon.types[1] = "and " + data.types[1].type.name + " type";
        }
        console.log(`Which pokemon is number ${pokemon.id}?`)
    }
    catch(error){
        console.error(error);
    }
    try{
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon-species/${pokeNum}`);
        
        if(!response.ok){
            throw new Error("Could not fetch resource");
        }

        data = await response.json();
        pokemon.color = data.color.name;
        pokemon.shape = data.shape.name;

        let checkLang = false;
        let flavorLang = data.flavor_text_entries[0].language.name;
        let index = 0;
        let flavorLower = "";

        while(checkLang === false){
            if(flavorLang !== "en"){
                flavorLang = data.flavor_text_entries[index].language.name;
            } else if(flavorLang === "en" && ((data.flavor_text_entries[index].flavor_text).toLowerCase()).includes(pokemon.name.toLowerCase()) === false){
                pokemon.desc = data.flavor_text_entries[index].flavor_text.replaceAll('\n', " ").replaceAll('\f', " ");
                checkLang = true;
            }
            index += 1;
        }
        hints = [`Pokemon ${pokemon.id} is a ${pokemon.types[0]} type!`, 
                 `Pokemon ${pokemon.id} is ${pokemon.types[0]} ${pokemon.types[1]}!`, 
                 `Pokemon ${pokemon.id}'s primary color is ${pokemon.color}!`, 
                 `Pokemon ${pokemon.id}'s "shape" is ${pokemon.shape}!`,
                 `Pokemon ${pokemon.id}'s data entry says: ${pokemon.desc}`];
    }
    catch(error){
        console.error(error);
    }
};

async function fetchGuess(){
    try{
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${pokeNum}`);
        
        if(!response.ok){
            throw new Error("Could not fetch resource");
        }

        data = await response.json();

    }
    catch(error){
        console.error(error);
    }
    try{
        const response = await fetch(`https://pokeapi.co/api/v2/pokemon-species/${pokeNum}`);
        
        if(!response.ok){
            throw new Error("Could not fetch resource");
        }

        data = await response.json();
        pokemon.color = data.color.name;
        pokemon.shape = data.shape.name;

        let checkLang = false;
        let flavorLang = data.flavor_text_entries[0].language.name;
        let index = 0;
        let flavorLower = "";

        while(checkLang === false){
            if(flavorLang !== "en"){
                flavorLang = data.flavor_text_entries[index].language.name;
            } else if(flavorLang === "en" && ((data.flavor_text_entries[index].flavor_text).toLowerCase()).includes(pokemon.name.toLowerCase()) === false){
                pokemon.desc = data.flavor_text_entries[index].flavor_text;
                checkLang = true;
            }
            index += 1;
        }

    }
    catch(error){
        console.error(error);
    }
};

async function checkGuess(guess){
    try{
        let guessResponse = await fetch(`https://pokeapi.co/api/v2/pokemon/${guess.toLowerCase()}`);
        if(!guessResponse.ok){
            throw new Error("Could not fetch resource");
        }
        data = await guessResponse.json();

        console.log(`${capitalize(currentGuess)} is not correct! ${capitalize(currentGuess)} is number ${data.id} which is ${Math.abs(pokemon.id - data.id)} away from ${pokemon.id}`);
        hintTime();
    }
    catch(error){
        console.log(`${capitalize(currentGuess)} is not registered!`)
        hintTime();
    }
}


printPk.addEventListener("click", function() {
    
    console.log(pokemon);
    console.log(pokemon.id);
    console.log(pokemon.name);
    console.log(pokemon.types.length);
    if(pokemon.types.length === 1){
        console.log(pokemon.types[0].type.name, "mono typed");
    } else {
        console.log(pokemon.types[0], pokemon.types[1]);
    }
    console.log(pokemon.shape);
    console.log(pokemon.color);
    console.log(pokemon.desc);
});



function pokeGuess(){
    let guessForm = document.getElementById("currentGuess");
    currentGuess = guessForm.value;
    if(currentGuess.toLowerCase() === pokemon.name.toLowerCase()){
        console.log(`Congratulations! Pokemon ${pokemon.id} is ${capitalize(pokemon.name)}`)
    } else{
        let rightCount = 0;
        let lowerName = pokemon.name.toLowerCase();
        let lowerGuess = currentGuess.toLowerCase();
        for(let i=0; i < pokemon.name.length; i++){
            if(lowerName[i] === lowerGuess[i]){
                rightCount += 1
            }
        }
        if(rightCount/pokemon.name.length >= .8){
            console.log(`Congratulations! Pokemon ${pokemon.id} is ${capitalize(pokemon.name)}`);
        }else{
            checkGuess(currentGuess);

        }
    }
};

function hintTime(){
    numGuesses += 1
    if(numGuesses%2 === 0){
        console.log(hints[hintIndex])
        hintIndex += 1
        if(hintIndex >= hints.length){
            hintIndex -= 1
        }
        
    }
}

function skip(){
    console.log(`Pokemon ${pokemon.id} was ${capitalize(pokemon.name)}, nice try.`)
    hintIndex = 0
    numGuesses = 0
    fetchAnswer()
}